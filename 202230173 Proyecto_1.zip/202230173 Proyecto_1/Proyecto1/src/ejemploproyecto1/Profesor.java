/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemploproyecto1;

/**
 *
 * @author Dell Inspiron 15
 */
public class Profesor {

    String codigo;
    String nombre;
    String apellido;
    String correo;
    String contrasenia;
    String genero;

    public Profesor(String codigo, String nombre, String apellido,
            String correo, String contrasenia, String genero) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.contrasenia = contrasenia;
        this.genero = genero;
    }

}
