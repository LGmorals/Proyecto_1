/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Administrador;

/**
 *
 * @author Dell Inspiron 15
 */
class Alumno {
 
    String codigo;
    String nombre;
    String apellido;
    
    
     public Alumno(String codigo, String nombre, String apellido, String columna3, String columna4) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.apellido = apellido;
}
}

