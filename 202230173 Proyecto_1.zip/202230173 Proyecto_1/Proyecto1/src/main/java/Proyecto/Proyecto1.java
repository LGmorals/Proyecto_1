/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Proyecto;

/**
 *
 * @author Dell Inspiron 15
 */
public class Proyecto1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
